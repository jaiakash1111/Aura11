import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Dior from './Dior.jsx';
import Armani from './Armani.jsx';
import YSL from './YSL.jsx';
import Creed from './Creed.jsx';
import JeanPaulGaultier from './JeanPaulGaultier.jsx';
import Gucci from './Gucci.jsx';
import Chanel from './Chanel.jsx';
import Versace from './Versace.jsx';
import TomFord from './TomFord.jsx';
import HugoBoss from './HugoBoss.jsx';
import Prada from './Prada.jsx';
import Burberry from './Burberry.jsx';
import PacoRabanne from './PacoRabanne.jsx';
import CalvinKlein from './CalvinKlein.jsx';
import Others from './Others.jsx';
export default function Shop(){
  return (
    <div className='p-10'>
      <h2 className='text-3xl font-bold mb-6'>Shop by Brand</h2>
      <div className='grid grid-cols-2 md:grid-cols-3 gap-4'>

        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='dior'>Dior</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='armani'>Armani</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='ysl'>YSL</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='creed'>Creed</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='jeanpaulgaultier'>JeanPaulGaultier</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='gucci'>Gucci</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='chanel'>Chanel</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='versace'>Versace</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='tomford'>TomFord</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='hugoboss'>HugoBoss</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='prada'>Prada</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='burberry'>Burberry</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='pacorabanne'>PacoRabanne</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='calvinklein'>CalvinKlein</Link>
        <Link className='p-4 border rounded-lg text-center hover:bg-gray-100' to='others'>Others</Link>
      </div>
      <Routes>

        <Route path='dior' element={<Dior/>}/>
        <Route path='armani' element={<Armani/>}/>
        <Route path='ysl' element={<YSL/>}/>
        <Route path='creed' element={<Creed/>}/>
        <Route path='jeanpaulgaultier' element={<JeanPaulGaultier/>}/>
        <Route path='gucci' element={<Gucci/>}/>
        <Route path='chanel' element={<Chanel/>}/>
        <Route path='versace' element={<Versace/>}/>
        <Route path='tomford' element={<TomFord/>}/>
        <Route path='hugoboss' element={<HugoBoss/>}/>
        <Route path='prada' element={<Prada/>}/>
        <Route path='burberry' element={<Burberry/>}/>
        <Route path='pacorabanne' element={<PacoRabanne/>}/>
        <Route path='calvinklein' element={<CalvinKlein/>}/>
        <Route path='others' element={<Others/>}/>
      </Routes>
    </div>
  );
}